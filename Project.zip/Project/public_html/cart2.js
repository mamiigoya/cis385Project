/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


  var products = [
                "001",
                "002",
                "003",
                "004"
            ];
            var descriptions = [
                "Decorative Candles",
                "Aromatherapy Candles",
                "Scented Candles",
                "Tea Light Candles"];
            
            var prices = [
                    15.89,
                    20.65,
                    30.00,
                    10.78];
   
            function startProducts() {
                for (var i = 0; i < products.length; i++) {
                    document.getElementById("products").innerHTML +=
                            "<tr><td><strong>" + products[i] +
                            "</strong> " + descriptions[i] +
                            "</td><td valign='top'>Price: $" + prices[i] + "<br>" +
                            "<button onclick='addToCart(\"" + products[i] + "\",1)'>Add To Cart</button></td></tr>";
                }
                details();
            }
            function setcookie(cname, cvalue, exdays) {
                var d = new Date();
                d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                var expires = "expires=" + d.toUTCString();
                document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
            }
            function addToCart(p, qty) {
                alert("Product " + getcookie(p) + " qty: " + qty);
                if (getcookie(p)) {
                    setcookie(p, (parseInt(getcookie(p)) + 1));
                } else {
                    setcookie(p, qty, 30);
                }
                details();
            }
            function getcookie(cookie2find) {
                var cookievalue = "", str = document.cookie;
                var cookie_array = str.split(";");
                for (var i = 0; i < cookie_array.length; i++)
                {
                    var B = cookie_array[i].split("=");
                    var c2f = "";
                    if (i !== 0)
                        c2f = " " + cookie2find;
                    else
                        c2f = cookie2find;
                    if (B[0] === c2f) {
                        cookievalue = B[1];
                        break;
                    }
                }
                return cookievalue;
            }
            function details() {
                var cookievalue = "", str = document.cookie;
                var cookie_array = str.split(";");
                var x = "<table style='width:50%;' class='table'>";
                x += "<tr><th>Product ID</th>";
                x += "<th>Product Description</th>";
                x += "<th>Unit Price</th>";
                x += "<th>Quantity</th>";
                x += "<th>Delete</th>";
                x += "</tr>";
                if (document.cookie.length !== 0)
                    for (var i = 0; i < cookie_array.length; i++)
                    {
                        var B = cookie_array[i].split("=");
                        x += "<tr><td style='width:10;'>" + B[0] + "</td>";
                        x += "<td>"+descriptions[i]+"</td>" +
                                "<td>0</td>" +
                                "<td style='width:10;'>" + B[1] + "</td>" +
                                "<td><input type='button' value='Delete' onclick='deleteProduct(\"" + B[0] + "\")'></td>" +
                                "</tr>";
                    }
                x += "</table>";
                document.getElementById("cart").innerHTML = x;
                return cookievalue;
            }
            function deleteProduct(p) {
                setcookie(p, "", -1);
                details();
            }
            
            function filterIt(arr, searchKey) {
                return arr.filter(function (obj) {
                    return Object.keys(obj).some(function (key) {
                        return obj[key].includes(searchKey);
                    });
                });
            }